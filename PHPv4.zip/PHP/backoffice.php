<html lang="fr">

	<head>
		<link href="" rel="stylesheet">
		<meta charset="utf-8">
		<title>Panneau de gestion de la billeterie</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="style_tennis.css">
	</head>

	<body>
	<header>
        <div class="logo">
            <img id="logo__img" src="image/OPENPARC_LOGO.jpg" alt="logo tennis">
			<img id="logo__img2" src="image/ATP 250.png" alt="logo ATP">
        </div>
        <nav class="navbar">
            <div class="navbar__left">
                <h1>Bienvenue</h1>   
            </div>
            <div class="navbar__right">
                <a href="login.php">Se connecter</a>
            </div>
        </nav>
    </header>
	<div class="container">
		<form class="ChoixAction_form" action="" method="post">
			<label class="ChoixAction_text" for="ChoixAction">Que voulez-vous faire?</label>
			<p>
				<select name="ChoixAction" class="ChoixAction">
					<option value="modif" <?php if (isset($ChoixAction)){ if( $ChoixAction=="modif"){ echo "selected";}}?>>modification des tickets</option>
					<option value="ajout" <?php if (isset($ChoixAction)){ if( $ChoixAction=="ajout"){ echo "selected";}}?>>ajout de tickets</option>
				</select>
			</p>
			<input class="ChoixAction_valider" type="submit" value="confirmer" name="submit_action">
		</form> 

		<?php
		 function connectDb(){
			  $host = 'localhost'; // ou sql.hebergeur.com
			  $user = 'p2000616';      // ou login
			  $pwd = '561912';      // ou xxxxxx
			  $db = 'p2000616';
		  try {
			   $bdd = new PDO('mysql:host='.$host.';dbname='.$db.
							  ';charset=utf8', $user, $pwd,
						  array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			   return $bdd;
			  } catch (Exception $e) {
			   exit('Erreur : '.$e->getMessage());
		  }
		 }
		 
			 if(isset($_POST['submit_action'])){
				 $choixAction=htmlspecialchars($_POST['ChoixAction']);
				 if($choixAction=='modif'){
					 
				$modifPrix = isset($_POST['modifPrix']) ? $_POST['modifPrix'] : '';
				
				
					 echo '<form class="action_backOffice" action="" method="post">
					<label class="action_label" for="ChoixTypeTicket">modification sur les tickets </label>
					<p>
						<select class="ChoixAction" name="ChoixTypeTicket" id="ChoixTypeTicket">
							<option value="plebGrand public" <?php if (isset($type) && $type=="plebGrand public") echo "selected";?>Grand public</option>
							<option value="licence" <?php if (isset($type) && $type=="licence") echo "selected";?>Licencié</option>
							<option value="charite" <?php if (isset($type) && $type=="charite") echo "selected";?>association</option>
						</select>
					</p>
					<label class="action_label" for="ChoixCatTicket">de categorie</label>
					<p>
						<select  class="ChoixAction" name="ChoixCatTicket" id="ChoixCatTicket">
							<option value="1" <?php if (isset($categorie) && $categorie=="1") echo "selected";?>Catégorie 3</option>
							<option value="2" <?php if (isset($categorie) && $categorie=="2") echo "selected";?>Catégorie 2 </option>
							<option value="3" <?php if (isset($categorie) && $categorie=="3") echo "selected";?>Catégorie 1</option>
						</select>
					</p>
					<label class="action_label" for="modifPrix">Modifier le prix des tickets</label>
					<p>
						<input  class="ChoixAction" type="number" id="modifPrix" name="modifPrix" value=' . "<?php echo htmlspecialchars($modifPrix);?> 	" . "
					</p>
					
					
					<input class='ChoixAction_valider' type='submit' value='MODIFICATION' name='submit_modif'>

					</form> "   ;
				 }
				 
				 else if($choixAction=='ajout'){
					 echo '<form class="action_backOffice" action="" method="post">
					 <label class="action_label" for="ChoixTypeTicket">modification sur les tickets </label>
					<p>
						<select  class="ChoixAction" name="ChoixTypeTicket" id="ChoixTypeTicket">
							<option value="plebGrand public" <?php if (isset($type) && $type=="plebGrand public") echo "selected";?>Grand public</option>
							<option value="licence" <?php if (isset($type) && $type=="licence") echo "selected";?>Licencié</option>
							<option value="charite" <?php if (isset($type) && $type=="charite") echo "selected";?>association</option>
						</select>
					</p>
					<label class="action_label" for="ChoixCatTicket">de categorie</label>
					<p>
						<select class="ChoixAction" name="ChoixCatTicket" id="ChoixCatTicket">
							<option value="1" <?php if (isset($categorie) && $categorie=="1") echo "selected";?>Catégorie 3</option>
							<option value="2" <?php if (isset($categorie) && $categorie=="2") echo "selected";?>Catégorie 2</option>
							<option value="3" <?php if (isset($categorie) && $categorie=="3") echo "selected";?>Catégorie 1</option>
						</select>
					</p>
					 <label class="action_label" for="nbTicketsToAdd">Ajouter des tickets</label>
						<p>
							<input class="ChoixAction" type="number" id="nbTicketsToAdd" name="nbTicketsToAdd">
						</p>
						<input class="ChoixAction_valider" type="submit" value="AJOUT" name="submit_ajout">

						</form>' ;
				 }
				 
			 }
			 
			 
			 
			 
			 
			 
			 if (isset($_POST['submit_modif'])) {//gestion modif
				$bdd = connectDb(); //connexion a la DB
								 // fin des données
				$ChoixCatTicket=htmlspecialchars($_POST['ChoixCatTicket']);
				$ChoixTypeTicket=htmlspecialchars($_POST['ChoixTypeTicket']);			
				$modifPrix=htmlspecialchars($_POST['modifPrix']);	
					
				try {
				
					//affichage des tickets dispo 
					$query = $bdd->prepare('UPDATE `billets` SET `prix`=:nvprix where `type`= :type and `categorie`= :categorie');// requête SQL

					$query->execute(array(

						 'nvprix' => $modifPrix,

						 'categorie' => $ChoixCatTicket,

						 'type' => $ChoixTypeTicket

						 )); // paramètres et exécution
					 
					 
					 echo $query->rowCount() . " records UPDATED successfully";
				} 
				catch(PDOException $e) {
					echo $e->getMessage();
				}
				 
				 
				 // fin des données
				 $query->closeCursor();
				 
			 }
			 
			 
			 else if (isset($_POST['submit_ajout'])) {//gestion ajout
				$bdd = connectDb(); //connexion a la DB
								 // fin des données
				$ChoixCatTicket=htmlspecialchars($_POST['ChoixCatTicket']);
				$ChoixTypeTicket=htmlspecialchars($_POST['ChoixTypeTicket']);	
				$nbTicketsToAdd=htmlspecialchars($_POST['nbTicketsToAdd']);	
				for($i=1;$i<=$nbTicketsToAdd;$i++){
					try {
					
						//affichage des tickets dispo 
						$query = $bdd->prepare('INSERT INTO `billets` (select `type`, `prix`, NULL, `categorie` from billets where `categorie`= :varCat and `type`= :varType LIMIT 1 );');// requête SQL

						$query->execute(array(


							 'varCat' => $ChoixCatTicket,

							 'varType' => $ChoixTypeTicket

							 )); // paramètres et exécution
						 
						 
						 echo $query->rowCount() . " records ADDED successfully <br /> ";
					} 
					catch(PDOException $e) {
						echo $e->getMessage();
					}
					 
					 
					 // fin des données
					 $query->closeCursor();
				}
			 }
			 
			$bdd = connectDb(); //connexion a la DB
			$nbTicketsDispo;
			try {
				
				//affichage des tickets dispo 
				 $query = $bdd->prepare("select * from billets;"); // requête SQL
				 $query->execute();
								  
								  
				 $zaegyuazey = $query -> rowCount ();
				 echo "<textarea class='nbTickets_affiche' name='nbTickets_affiche' readonly>nb de tickets disponibles : $zaegyuazey </textarea>";
			} 
			catch(PDOException $e) {
				echo $e->getMessage();
			}
				 
				 
				 // fin des données
			 $query->closeCursor(); 
		?>
	</div>
	
	<footer class="footer-basic">
        <div class="social">
            <a class="noborder" href="#"><img class="insta" src="image/instalogo.png" alt=""></img></a>
            <a class="noborder" href="#"><img class="fb" src="image/fblogo.png" alt=""></img></a>
            <a class="noborder"href="#"><img class="insta" src="image/twitterlogo.png" alt=""></img></a>
            <a class="noborder"href="#"><img class="insta" src="image/snaplogo.png" alt=""></img></a>
        </div>
        <ul class="list-inline">
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">Accueil</a></li>
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">Services</a></li>
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">A propos</a></li>
        </ul>
        <p class="copyright">Open tennis Auvergne Rhône Alpes 2022</p>
    </footer>





	</body>
</html>



