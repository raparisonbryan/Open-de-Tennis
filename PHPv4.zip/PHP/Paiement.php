<html lang="fr">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="Paiement.css">
	<title>Paiement</title>
</head>

<body>
    <header>
        <div class="logo">
            <img id="logo__img" src="image/OPENPARC_LOGO.jpg" alt="logo tennis">
			<img id="logo__img2" src="image/ATP 250.png" alt="logo ATP">
        </div>
        <nav class="navbar">
            <div class="navbar__left">
                <a href="Programme.html">Programme</a>
                <a href="Billeterie.php">Billeterie</a>
            </div>
            <div class="navbar__right">
                <a href="login.php">Se connecter</a>
            </div>
        </nav>
    </header>

    <h1 id=pagetitre>Paiement Open Tennis Lyon</h1>
    <h1 id="achat">Finaliser votre achat !</h1>
      <form id=paiement action="PaiementValider.html">
        <fieldset>
          <legend>Votre identité</legend>
          <ol>
            <li>
              <label for=nom>Nom</label>
              <input id=nom name=nom type=text placeholder="Prénom et nom" required autofocus>
            </li>
            <li>
              <label for=email>Email</label>
              <input id=email name=email type=email placeholder="exemple@domaine.com" required>
            </li>
            <li>
              <label for=telephone>Téléphone</label>
              <input id=telephone name=telephone type=tel placeholder="par ex&nbsp;: +3375500000000" required>
            </li>
          </ol>
        </fieldset>

        <fieldset>
          <legend>Adresse de livraison</legend>
            <ol>
              <li>
                <label for=adresse>Adresse</label>
                <textarea id=adresse name=adresse rows=5 required></textarea>
              </li>
              <li>
                <label for=codepostal>Code postal</label>
                <input id=codepostal name=codepostal type=text required>
              </li>
                <li>
                <label for=pays>Pays</label>
                <input id=pays name=pays type=text required>
              </li>
            </ol>
          </fieldset>
        <fieldset>
          <legend>Informations CB</legend>
          <ol>
            <li>
              <fieldset>
                <legend>Type de carte bancaire</legend>
                <ol>
                  <li>
                    <input id=visa name=type_de_carte type=radio>
                    <label for=visa>VISA</label>
                  </li>
                  <li>
                    <input id=amex name=type_de_carte type=radio>
                    <label for=amex>AmEx</label>
                  </li>
                  <li>
                    <input id=mastercard name=type_de_carte type=radio>
                    <label for=mastercard>Mastercard</label>
                  </li>
                </ol>
              </fieldset>
            </li>
            <li>
              <label for=numero_de_carte>N° de carte</label>
              <input id=numero_de_carte name=numero_de_carte type=number required>
            </li>
            <li>
              <label for=securite>Code sécurité</label>
              <input id=securite name=securite type=number required>
            </li>
            <li>
              <label for=nom_porteur>Nom du porteur</label>
              <input id=nom_porteur name=nom_porteur type=text placeholder="Même nom que sur la carte" required>
            </li>
          </ol>
        </fieldset>

        <fieldset>
          <button type=submit>J'achète !</button>
        </fieldset>
    </form>
	</body>

	<div class="footer-basic">
        <footer>
            <div class="social">
                <a class="noborder" href="#"><img class="insta" src="image/instalogo.png" alt=""></img></a>
                <a class="noborder" href="#"><img class="fb" src="image/fblogo.png" alt=""></img></a>
                <a class="noborder"href="#"><img class="insta" src="image/twitterlogo.png" alt=""></img></a>
                <a class="noborder"href="#"><img class="insta" src="image/snaplogo.png" alt=""></img></a>
            </div>
            <ul class="list-inline">
              <li class="list-inline-item"><a class="noborder" href="Accueil.html">Accueil</a></li>
              <li class="list-inline-item"><a class="noborder" href="Accueil.html">Services</a></li>
              <li class="list-inline-item"><a class="noborder" href="Accueil.html">A propos</a></li>
          </ul>
            <p class="copyright">Open tennis Auvergne Rhône Alpes 2022</p>
        </footer>
    </div>

    <?php			
				function connectDb(){
			  $host = 'localhost'; // ou sql.hebergeur.com
			  $user = 'p2000616';      // ou login
			  $pwd = '561912';      // ou xxxxxx
			  $db = 'p2000616';
		  try {
			   $bdd = new PDO('mysql:host='.$host.';dbname='.$db.
							  ';charset=utf8', $user, $pwd,
						  array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			   return $bdd;
			  } catch (Exception $e) {
			   exit('Erreur : '.$e->getMessage());
		  }
		 }
		 $bdd = connectDb();
				$kek=$_POST['IDs'];
				print_r($kek);
						try {
			
						//delete a l'achat, on recupere depuis Billeterie.php
						for($i=0;$i<count($kek);$i++){
							$query = $bdd->prepare('delete from `billets` where `id`=:varID');// requête SQL

							$query->execute(array(

								 'varID' => $kek[$i]
								 ));
							 
							 
							 echo $query->rowCount() . " records DELETED successfully";
							} 
						}
						catch(PDOException $e) {
						  echo $e->getMessage();
						}
					 
					 
						// fin des données
						$query->closeCursor();				
	?>

	
</html>