<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Login</title>
        <link rel="stylesheet" href="login.css" />
    </head>

    <body class="login_body">
    <header>
        <div class="logo">
            <img id="logo__img" src="image/OPENPARC_LOGO.jpg" alt="logo tennis">
			<img id="logo__img2" src="image/ATP 250.png" alt="logo ATP">
        </div>
        <nav class="navbar">
            <div class="navbar__left">
                <a href="Programme.html">Programme</a>
                <a href="Billeterie.php">Billeterie</a>
            </div>
            <div class="navbar__right">
                <a href="login.php">Se connecter</a>
            </div>
        </nav>
    </header>

    <main>
            <form class="login" action="" method="post">
                <label class="login__connexion" for="connexion">connexion</label>
                <input type="text" name="username" class="username" value="">
                <input type="password" name="password" class="password" value="">
                <input type="submit" name="envoi" value="envoi">
            </form>
    </main>

    <footer class="footer-basic">
        <div class="social">
            <a class="noborder" href="#"><img class="insta" src="image/instalogo.png" alt=""></img></a>
            <a class="noborder" href="#"><img class="fb" src="image/fblogo.png" alt=""></img></a>
            <a class="noborder"href="#"><img class="insta" src="image/twitterlogo.png" alt=""></img></a>
            <a class="noborder"href="#"><img class="insta" src="image/snaplogo.png" alt=""></img></a>
        </div>
        <ul class="list-inline">
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">Accueil</a></li>
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">Services</a></li>
            <li class="list-inline-item"><a class="noborder" href="Accueil.html">A propos</a></li>
        </ul>
        <p class="copyright">Open tennis Auvergne Rhône Alpes 2022</p>
    </footer>

    <?php
    function connectDb(){
        $host = 'localhost'; // ou sql.hebergeur.com
        $user = 'p2000616';      // ou login
        $pwd = '561912';      // ou xxxxxx
        $db = 'p2000616';
        try {
            $bdd = new PDO('mysql:host='.$host.';dbname='.$db.
                ';charset=utf8', $user, $pwd,
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            return $bdd;
        } catch (Exception $e) {
            exit('Erreur : '.$e->getMessage());
        }
    }

    if (isset($_POST['envoi'])) {//gestion classique, on recupere name
        $bdd = connectDb(); //connexion a la DB
        // fin des données
        $user=htmlspecialchars($_POST['username']);
        $PW=htmlspecialchars($_POST['password']);


        //affichage des tickets dispo
        $query = $bdd->prepare("SELECT `login`, `mot` FROM `Utilisateur` WHERE 1"); // requête SQL
        $query->execute(); // paramètres et exécution
        $verif=0;
        if(($zaegyuazey=$query -> rowCount ())>0){
            while ($data = $query->fetch()) // lecture par ligne
            {



                if ($user==$data[0]){
                    if ($PW==$data[1]){
                        $verif=1;

                    }
                }
            }
        }
        // fin des données
        $query->closeCursor();
        if($verif==1){
            header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiK1s_yk6r1AhWC3oUKHU4EA6QQ3yx6BAgDEAI&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DJqa1Ugmv9yY&usg=AOvVaw0SZdxo9knzf0lvOjUAW5p0");
            echo "$verif";
        }
    }
    ?>
    </body>
</html>